CREATE VIEW view_stock_supplier AS
  SELECT
    `sss_ms`.`goods`.`g_id`        AS `g_id`,
    `sss_ms`.`goods`.`g_name`      AS `g_name`,
    `sss_ms`.`goods`.`g_spec`      AS `g_spec`,
    `sss_ms`.`supply`.`sup_id`     AS `sup_id`,
    `sss_ms`.`supply`.`sup_unit_p` AS `sup_unit_p`,
    `sss_ms`.`supply`.`sup_ori`    AS `sup_ori`,
    `sss_ms`.`supply`.`sup_maxp`   AS `sup_maxp`
  FROM (`sss_ms`.`goods`
    JOIN `sss_ms`.`supply` ON ((`sss_ms`.`supply`.`g_id` = `sss_ms`.`goods`.`g_id`)));

