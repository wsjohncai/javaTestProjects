CREATE VIEW view_sale_rcd AS
  SELECT
    `sss_ms`.`sale`.`sale_id`      AS `销售编号`,
    `sss_ms`.`customer`.`c_name`   AS `客户姓名`,
    `sss_ms`.`goods`.`g_name`      AS `商品名称`,
    `sss_ms`.`sale`.`sale_num`     AS `数量`,
    `sss_ms`.`sale`.`sale_total_p` AS `销售总价格`,
    `sss_ms`.`sale`.`sale_date`    AS `日期`,
    `sss_ms`.`sale`.`s_id`         AS `s_id`
  FROM ((`sss_ms`.`sale`
    JOIN `sss_ms`.`goods` ON ((`sss_ms`.`sale`.`g_id` = `sss_ms`.`goods`.`g_id`))) JOIN `sss_ms`.`customer`
      ON ((`sss_ms`.`sale`.`c_id` = `sss_ms`.`customer`.`c_id`)));

