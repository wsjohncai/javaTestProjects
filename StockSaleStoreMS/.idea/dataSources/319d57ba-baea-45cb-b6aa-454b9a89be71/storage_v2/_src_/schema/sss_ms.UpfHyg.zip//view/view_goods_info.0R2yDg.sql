CREATE VIEW view_goods_info AS
  SELECT
    `sss_ms`.`goods`.`g_id`      AS `商品编号`,
    `sss_ms`.`goods`.`g_name`    AS `商品名`,
    `sss_ms`.`goodtype`.`t_name` AS `商品类型`,
    `sss_ms`.`goods`.`g_spec`    AS `型号`,
    `sss_ms`.`goods`.`g_unit_p`  AS `单价`,
    `sss_ms`.`goods`.`g_num`     AS `库存`
  FROM (`sss_ms`.`goods`
    JOIN `sss_ms`.`goodtype` ON ((`sss_ms`.`goods`.`t_id` = `sss_ms`.`goodtype`.`t_id`)));

