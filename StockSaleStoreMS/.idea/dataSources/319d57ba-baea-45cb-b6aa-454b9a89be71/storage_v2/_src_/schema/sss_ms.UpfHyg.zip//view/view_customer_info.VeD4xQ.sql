CREATE VIEW view_customer_info AS
  SELECT
    `sss_ms`.`customer`.`c_id`    AS `客户编号`,
    `sss_ms`.`customer`.`c_name`  AS `客户名`,
    `sss_ms`.`customer`.`c_con`   AS `联系方式`,
    `sss_ms`.`customer`.`c_addr`  AS `客户地址`,
    `sss_ms`.`credit`.`cre_limit` AS `购买限制`
  FROM (`sss_ms`.`customer`
    JOIN `sss_ms`.`credit` ON ((`sss_ms`.`customer`.`cre_lv` = `sss_ms`.`credit`.`cre_lv`)));

